$ make all
$ dmesg -C  # clear dmesg
$ insmod hello.ko
$ lsmod | grep "hello"
$ dmesg
[72101.439755] Hello world from kernel!!

$rmmod hello

